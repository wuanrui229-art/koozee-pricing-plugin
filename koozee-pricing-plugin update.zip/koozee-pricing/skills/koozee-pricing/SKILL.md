---
name: koozee-pricing
description: Calculate KOOZEE feature credit pricing, member/non-member recommendations, and conservative/aggressive margins from business costs. Use when the user mentions KOOZEE, 积分定价, 定价建议, 成本测算, Seedance, Seedance mini, Gemini, Shopify 模特套图, or wants a pricing formula.
---

# KOOZEE Pricing

Use this skill as a KOOZEE pricing advisor. Keep the answer practical, business-facing, and explicit about units.

## Core Interpretation

KOOZEE uses credits/美豆 as the user-facing billing unit. The pricing model must separate three layers:

- `第三方成本`: supplier or model API cost paid by KOOZEE.
- `内部美豆成本`: internal cost basis per credit, currently `0.156` CNY per credit.
- `用户感知费用`: credits charged to the user multiplied by user-side credit price.

Do not treat internal credit cost as user-side credit price.

## Data Sources

Always separate data into these confidence levels:

- `截图/网页记录`: prices seen in the KOOZEE UI or screenshot, usable as reference.
- `测算`: values derived from formulas, discounts, or assumptions.
- `待确认`: values that need production billing logs, backend strategy center, or a manual test.

Load `../../assets/pricing-defaults.json` when you need built-in defaults.

## Default Assumptions

Use these defaults unless the user provides a different business assumption:

- User-side CNY credit price: `0.186` CNY per credit, from offline large packages (`1.6W/3.75W/16W Credit`).
- User-side USD credit price: about `$0.05` per credit, from online `300 Credit = $14.9`; use as USD reference only unless the user asks for USD pricing.
- Internal credit cost: `0.156` CNY per credit, from `0.78 / 5 = 0.156`.
- Image generation cost benchmark: `0.66` CNY per image.
- VIP discount coefficient: `0.5`.
- Conservative target gross margin: `25%`.
- Aggressive target gross margin: `50%`.
- Monthly member credits reference: `600` credits.
- Current displayed packages: VIP monthly `¥159/$22.9`, VIP annual `¥1399/$199.9`, single-purchase `300/700/1500/3500 Credit`, offline large packages using about `¥0.186/credit`.

Do not mix these two concepts:

- `用户侧每积分售价`: how much the user pays per credit.
- `内部美豆成本`: internal cost basis per credit.

Subscription orders are revenue/package assumptions. Use the configured `0.186` CNY default for RMB recommendations unless the user provides a different package or weighted-average price.

## Formulas

Use these formulas exactly:

```text
用户单次费用 = 单次积分数量 * 每积分售价
内部美豆成本 = 单次积分数量 * 内部每积分成本
毛利 = 用户单次费用 - 单次成本
毛利率 = (用户单次费用 - 单次成本) / 用户单次费用
成本覆盖积分 = ROUNDUP(单次成本 / 用户侧每积分售价, 0)
会员口径积分 = ROUNDUP(单次成本 / (用户侧每积分售价 * (1 - 目标毛利率)), 0)
非会员建议积分 = ROUNDUP(会员口径积分 / 会员折扣系数, 0)
```

When the unit is seconds, calculate per second first and then multiply by duration:

```text
视频总积分 = 每秒积分 * 秒数
视频总成本 = 每秒成本 * 秒数
```

## Recommendation Style

For each pricing request, return:

- Cost per unit.
- Cost-covering credits.
- User fee per unit.
- Internal credit cost.
- Conservative recommendation in member-pricing terms.
- Aggressive recommendation in member-pricing terms.
- Non-member recommendation converted from member recommendation.
- Clear `待确认` notes for missing or unverified values.

Only include current credits, current user fee, current internal credit cost, current gross margin,
and current gross margin rate when the user explicitly provides current credits in the request.
Do not infer current credits from old backend records, screenshots, examples, or previous
conversations.

Keep the recommendation decisive:

- If current credits are below the conservative suggestion, call it below the commercial baseline.
- If current credits are between conservative and aggressive, call it acceptable but not high-margin.
- If current credits meet or exceed aggressive, call it high-margin enough for commercial testing.
- If current credits are not provided, do not judge the current price. Instead, judge only the
  recommended pricing bands.

For the final answer, use Markdown tables instead of prose bullets. Use this compact output structure:

```text
输入：功能、单位、第三方成本
当前：仅当用户明确提供当前积分时，展示当前积分、用户感知费用、内部美豆成本、公司毛利、公司毛利率
建议：成本覆盖积分、会员口径保守积分、会员口径激进积分、非会员保守建议积分、非会员激进建议积分
判断：未提供当前积分时只判断建议档位；提供当前积分时再判断低于保守 / 介于保守和激进 / 达到激进
待确认：供应商真实成本、会员是否允许小数积分、最终取整规则
```

## Seedance Mini Test

For Seedance mini, use these known cost references:

- 480p: `0.23` CNY per second.
- 720p: `0.50` CNY per second.

If using the default user-side credit price `0.186` CNY and commercial target margins:

- 720p cost-covering credits per second: `ROUNDUP(0.50 / 0.186, 0) = 3`.
- 720p member conservative credits per second: `ROUNDUP(0.50 / (0.186 * 0.75), 0) = 4`.
- 720p member aggressive credits per second: `ROUNDUP(0.50 / (0.186 * 0.50), 0) = 6`.
- 720p non-member conservative credits per second: `ROUNDUP(4 / 0.5, 0) = 8`.
- 720p non-member aggressive credits per second: `ROUNDUP(6 / 0.5, 0) = 12`.

Compare current prices with the matching member/non-member tier only when the user provides current credits. Do not assume the current online price.

## Local Calculator Script

If the user wants a quick calculation, run:

```bash
node /Users/wendy/plugins/koozee-pricing/scripts/price.mjs --cost 0.50 --credit-price 0.186 --unit 秒
```

Use `--unit 秒` for video prices or `--unit 次` for generation prices.
