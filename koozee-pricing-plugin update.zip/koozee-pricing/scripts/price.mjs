#!/usr/bin/env node

const args = process.argv.slice(2);

function readFlag(name, fallback = undefined) {
  const flag = `--${name}`;
  const index = args.indexOf(flag);
  if (index === -1) return fallback;
  const value = args[index + 1];
  if (!value || value.startsWith("--")) return true;
  return value;
}

function numberFlag(name, fallback) {
  const raw = readFlag(name, fallback);
  const value = Number(raw);
  if (!Number.isFinite(value)) {
    throw new Error(`参数 --${name} 需要是数字，当前是 ${raw}`);
  }
  return value;
}

function creditsFor(cost, creditPrice, margin) {
  return Math.ceil(cost / (creditPrice * (1 - margin)));
}

function money(value) {
  return Number(value.toFixed(4));
}

function percent(value) {
  return `${(value * 100).toFixed(1)}%`;
}

function fmt(value, suffix = "") {
  if (value === null || value === undefined || Number.isNaN(value)) return "待确认";
  return `${value}${suffix}`;
}

if (readFlag("help", false)) {
  console.log(`KOOZEE 定价计算器

用法:
  node scripts/price.mjs --cost 0.50 --unit 秒

参数:
  --cost                 单次/每秒成本，人民币
  --credit-price          用户侧每积分售价，默认 0.186
  --internal-credit-cost  内部每积分成本，默认 0.156
  --current-points        当前积分，选填
  --member-discount       会员折扣系数，默认 0.5
  --conservative-margin   保守毛利率，默认 0.25
  --aggressive-margin     激进毛利率，默认 0.50
  --unit                  计费单位，默认 次
  --json                  输出 JSON，默认输出 Markdown 表格
`);
  process.exit(0);
}

const cost = numberFlag("cost", NaN);
if (!Number.isFinite(cost)) {
  console.error("缺少必填参数：--cost，例如 --cost 0.50");
  process.exit(1);
}

const creditPrice = numberFlag("credit-price", 0.186);
const internalCreditCost = numberFlag("internal-credit-cost", 0.156);
const currentPointsRaw = readFlag("current-points", "");
const currentPoints = currentPointsRaw === "" ? null : Number(currentPointsRaw);
if (currentPoints !== null && !Number.isFinite(currentPoints)) {
  console.error(`参数 --current-points 需要是数字，当前是 ${currentPointsRaw}`);
  process.exit(1);
}

const memberDiscount = numberFlag("member-discount", 0.5);
const conservativeMargin = numberFlag("conservative-margin", 0.25);
const aggressiveMargin = numberFlag("aggressive-margin", 0.5);
const unit = readFlag("unit", "次");

const costCoverCredits = Math.ceil(cost / creditPrice);
const memberConservativeCredits = creditsFor(cost, creditPrice, conservativeMargin);
const memberAggressiveCredits = creditsFor(cost, creditPrice, aggressiveMargin);
const nonMemberCostCoverCredits = Math.ceil(costCoverCredits / memberDiscount);
const nonMemberConservativeCredits = Math.ceil(memberConservativeCredits / memberDiscount);
const nonMemberAggressiveCredits = Math.ceil(memberAggressiveCredits / memberDiscount);

const currentUserFee = currentPoints === null ? null : currentPoints * creditPrice;
const currentInternalCreditCost = currentPoints === null ? null : currentPoints * internalCreditCost;
const currentGrossProfit = currentUserFee === null ? null : currentUserFee - cost;
const currentGrossMargin = currentUserFee === null || currentUserFee === 0 ? null : currentGrossProfit / currentUserFee;

let verdict = "当前积分未知，先按成本给出建议。";
if (currentPoints !== null) {
  if (currentPoints < nonMemberConservativeCredits) {
    verdict = "若当前积分为非会员价，则低于非会员保守建议。";
  } else if (currentPoints < nonMemberAggressiveCredits) {
    verdict = "若当前积分为非会员价，则介于非会员保守和激进之间。";
  } else {
    verdict = "若当前积分为非会员价，则达到非会员激进建议。";
  }
}

const result = {
  inputs: {
    costCny: cost,
    unit,
    creditPriceCny: creditPrice,
    internalCreditCostCny: internalCreditCost,
    currentCredits: currentPoints,
    memberDiscountCoefficient: memberDiscount,
    conservativeTargetGrossMargin: conservativeMargin,
    aggressiveTargetGrossMargin: aggressiveMargin
  },
  current: currentPoints === null ? null : {
    userFeeCny: money(currentUserFee),
    internalCreditCostCny: money(currentInternalCreditCost),
    grossProfitCny: money(currentGrossProfit),
    grossMargin: money(currentGrossMargin)
  },
  recommendations: {
    memberCostCoverCredits: costCoverCredits,
    memberConservativeCredits,
    memberAggressiveCredits,
    nonMemberCostCoverCredits,
    nonMemberConservativeCredits,
    nonMemberAggressiveCredits,
    costCoverUserFeeCny: money(costCoverCredits * creditPrice),
    conservativeUserFeeCny: money(memberConservativeCredits * creditPrice),
    aggressiveUserFeeCny: money(memberAggressiveCredits * creditPrice)
  },
  verdict
};

if (readFlag("json", false)) {
  console.log(JSON.stringify(result, null, 2));
  process.exit(0);
}

console.log("| 模块 | 字段 | 数值 |");
console.log("|---|---|---:|");
console.log(`| 输入 | 第三方成本 | ${cost} 元/${unit} |`);
console.log(`| 默认假设 | 用户侧每积分售价 | ${creditPrice} 元/积分 |`);
console.log(`| 默认假设 | 内部每积分成本 | ${internalCreditCost} 元/积分 |`);
if (currentPoints !== null) {
  console.log(`| 输入 | 当前积分 | ${fmt(currentPoints, ` 积分/${unit}`)} |`);
  console.log(`| 当前测算 | 用户感知费用 | ${money(currentUserFee)} 元/${unit} |`);
  console.log(`| 当前测算 | 内部美豆成本 | ${money(currentInternalCreditCost)} 元/${unit} |`);
  console.log(`| 当前测算 | 公司毛利 | ${money(currentGrossProfit)} 元/${unit} |`);
  console.log(`| 当前测算 | 公司毛利率 | ${percent(currentGrossMargin)} |`);
}
console.log(`| 会员定价口径 | 成本覆盖 | ${costCoverCredits} 积分/${unit} |`);
console.log(`| 会员定价口径 | 保守建议，目标 ${percent(conservativeMargin)} 毛利 | ${memberConservativeCredits} 积分/${unit} |`);
console.log(`| 会员定价口径 | 激进建议，目标 ${percent(aggressiveMargin)} 毛利 | ${memberAggressiveCredits} 积分/${unit} |`);
console.log(`| 非会员建议 | 成本覆盖 | ${nonMemberCostCoverCredits} 积分/${unit} |`);
console.log(`| 非会员建议 | 保守建议，按会员 ${memberDiscount * 10} 折反推 | ${nonMemberConservativeCredits} 积分/${unit} |`);
console.log(`| 非会员建议 | 激进建议，按会员 ${memberDiscount * 10} 折反推 | ${nonMemberAggressiveCredits} 积分/${unit} |`);
console.log(`| 判断 | 结果 | ${verdict} |`);
